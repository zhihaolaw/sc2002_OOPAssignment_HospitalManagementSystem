package hospital_system;

public interface LoginSystem {
    boolean login(String password);
    void changePassword();
    void showMenu();
}

